import { useState, useEffect } from 'react';

export default function App() {

  const [selected, setSelected] = useState('story');
  const [ans, setAns] = useState([]);
  const [score, setScore] = useState(null);
  const [time, setTime] = useState(60);
  const [done, setDone] = useState(false);

  const [xp, setXp] = useState(0);
  const [level, setLevel] = useState(1);
  const [mission, setMission] = useState(1);

  const menu = [
    { id: 'story', title: 'Story Mode', desc: 'Görevleri tamamla' },
    { id: 'online', title: 'Test Mode', desc: 'Süreli test' },
    { id: 'characters', title: 'Karakterler', desc: 'Kadir ve ekibi' },
  ];

  const topics = [
    { t: 'Denklemler', d: 'Bilinmeyenleri bulma', f: 'ax + b = c' },
    { t: 'Üslü Sayılar', d: 'Çarpma hızlandırma', f: 'a^m · a^n = a^(m+n)' },
    { t: 'Köklü Sayılar', d: 'Karekök işlemleri', f: '√a · √b = √ab' },
    { t: 'Geometri', d: 'Açı hesapları', f: 'A + B + C = 180°' }
  ];

  const qs = [
    { q: '2x + 5 = 15 ise x=?', a: '5', o: ['3','4','5','6'] },
    { q: '3^2 + 4^2 = ?', a: '25', o: ['20','25','30','35'] },
    { q: '√81 = ?', a: '9', o: ['7','8','9','10'] },
    { q: '15/3 = ?', a: '5', o: ['3','4','5','6'] },
  ];

  useEffect(() => {
    if (selected !== 'online' || done) return;
    if (time <= 0) return finish();
    const t = setTimeout(() => setTime(time - 1), 1000);
    return () => clearTimeout(t);
  }, [time, selected, done]);

  function addXP(points){
    let newXP = xp + points;
    let newLevel = level;
    if (newXP >= 100){
      newLevel++;
      newXP -= 100;
    }
    setXp(newXP);
    setLevel(newLevel);
  }

  function finish(){
    let s = 0;
    qs.forEach((x,i)=>{
      if(ans[i] === x.a) s++;
    });
    setScore(s);
    setDone(true);
    addXP(s*20);
    setMission(mission+1);
  }

  return (
    <div style={{display:'flex',minHeight:'100vh',background:'#000',color:'#fff'}}>

      <div style={{width:'25%',padding:20,borderRight:'1px solid gray'}}>
        <h2>MATH GAME</h2>
        <p>Level {level} | XP {xp}</p>

        {menu.map(m=>(
          <div key={m.id}
            onClick={()=>{setSelected(m.id);setAns([]);setScore(null);setDone(false);setTime(60);}}
            style={{padding:10,marginTop:10,background:'#111',cursor:'pointer'}}
          >
            <b>{m.title}</b>
            <p>{m.desc}</p>
          </div>
        ))}
      </div>

      <div style={{padding:20,flex:1}}>

        {selected==='story' && (
          <div>
            <h1>Story Mode</h1>
            <p>Görev {mission}</p>

            {topics.map((x,i)=>(
              <div key={i} style={{marginTop:10,background:'#111',padding:10}}>
                <b>{x.t}</b>
                <p>{x.d}</p>
                <code>{x.f}</code>
              </div>
            ))}
          </div>
        )}

        {selected==='online' && (
          <div>
            <h1>Test Mode</h1>
            <p>Süre {time}</p>

            {qs.map((x,i)=>(
              <div key={i}>
                <p>{x.q}</p>
                {x.o.map(o=>(
                  <button key={o}
                    onClick={()=>{
                      const n=[...ans];n[i]=o;setAns(n);
                    }}
                    style={{margin:5}}
                  >
                    {o}
                  </button>
                ))}
              </div>
            ))}

            <button onClick={finish}>Bitir</button>

            {score!==null && <h2>Skor: {score}</h2>}
          </div>
        )}

        {selected==='characters' && (
          <div>
            <h1>Characters</h1>
            <p>Kadir ve Öğretmen</p>
          </div>
        )}

      </div>

    </div>
  )
}
